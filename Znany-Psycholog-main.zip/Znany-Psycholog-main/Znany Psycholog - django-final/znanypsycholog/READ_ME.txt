Dzień dobry,

Przesyłamy Panu dokończony projekt aplikacji Znany Psycholog.

Z uszanowaniem,
Oliwia Bujak,
Krzysztof Majda,
Karolina Matusiak,
Agata Schulz,
Karolina Sieroń,
Mikołaj Słomczyński